"""
Genera PDFs de EJEMPLO de hipotecas con el formato que espera tu pipeline:

  - Título del PDF  -> tamaño 20      (trocear: sección)
  - Cabecera artículo -> tamaño 12    (trocear: un Chunk por artículo, id = texto antes de " · ")
  - Cuerpo          -> tamaño 10
  - Pie de página   -> tamaño 8       (limpiar lo elimina: tam < 9)
  - "Metadatos del documento original" al final (limpiar lo elimina)

AVISO: contenido genérico, NO es documentación real del banco.
Los valores propios del banco están como [A CONFIRMAR POR EL BANCO].
Los nombres de archivo empiezan por EJEMPLO_ para poder distinguirlos.
"""
import json
from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.utils import simpleSplit

TBC = "[A CONFIRMAR POR EL BANCO]"

MARGEN = 56
ANCHO_TEXTO = A4[0] - 2 * MARGEN
ALTO = A4[1]

# Cada documento: (archivo, título, [(id, título del artículo, texto)])
DOCUMENTOS = [
    ("EJEMPLO_01_tipos_de_hipoteca.pdf", "Guía de tipos de hipoteca", [
        ("HIP-TIP-01", "Hipoteca de tipo fijo",
         "En una hipoteca a tipo fijo el tipo de interés se mantiene igual durante toda la vida del "
         "préstamo. La cuota mensual es previsible y no cambia aunque varíen los tipos del mercado. "
         "Suele tener un tipo inicial más alto que la variable, porque el cliente paga por tener "
         f"certeza. Plazos de tipo fijo que ofrece el banco: {TBC}."),
        ("HIP-TIP-02", "Hipoteca de tipo variable",
         "En una hipoteca a tipo variable el interés es la suma de un índice de referencia (por "
         "ejemplo, el Euríbor) y un diferencial fijo pactado en el contrato. El tipo se revisa cada "
         "cierto tiempo, normalmente cada seis o doce meses, por lo que la cuota puede subir o bajar. "
         f"Índice de referencia y periodo de revisión: {TBC}."),
        ("HIP-TIP-03", "Hipoteca de tipo mixto",
         "La hipoteca mixta combina ambos modelos. Durante un primer periodo se aplica un tipo fijo "
         "y después pasa a tipo variable (índice de referencia más diferencial) hasta el final del "
         f"plazo. Duración del periodo fijo inicial y diferencial: {TBC}."),
        ("HIP-TIP-04", "Cómo elegir entre los tipos",
         "El tipo fijo conviene a quien prioriza cuotas estables. El tipo variable conviene a quien "
         "acepta que la cuota fluctúe a cambio de un coste inicial normalmente menor. El tipo mixto "
         "ofrece estabilidad al principio y exposición a los cambios del mercado después. La mejor "
         "opción depende del presupuesto, la tolerancia al riesgo y los planes del cliente con la vivienda."),
    ]),
    ("EJEMPLO_02_solicitud.pdf", "Procedimiento de solicitud de la hipoteca", [
        ("HIP-SOL-01", "Consulta inicial y simulación",
         "El proceso empieza con una consulta en la oficina o por internet. El banco realiza una "
         "simulación con el importe solicitado, el plazo, el valor de la vivienda y los ingresos del "
         "solicitante para estimar la cuota y la capacidad de pago."),
        ("HIP-SOL-02", "Presentación y estudio de la solicitud",
         "El solicitante entrega la solicitud con la documentación justificativa. El banco analiza "
         "la solvencia, el historial crediticio y la relación entre deudas e ingresos. "
         f"Plazo habitual de estudio: {TBC}."),
        ("HIP-SOL-03", "Tasación de la vivienda",
         "El banco exige una tasación del inmueble realizada por una sociedad de tasación homologada. "
         "El importe del préstamo se limita a un porcentaje del menor valor entre la tasación y el "
         f"precio de compra. Porcentaje máximo de financiación: {TBC}."),
        ("HIP-SOL-04", "Oferta, notaría y firma",
         "Si la operación se aprueba, el banco entrega la oferta vinculante. El cliente revisa la "
         "documentación precontractual (como la Ficha Europea de Información Normalizada) con la "
         "antelación que marca la normativa y acude a la notaría a firmar la escritura, que después "
         f"se inscribe en el Registro de la Propiedad. Plazo de validez de la oferta: {TBC}."),
    ]),
    ("EJEMPLO_03_documentacion.pdf", "Documentación necesaria para solicitar la hipoteca", [
        ("HIP-DOC-01", "Documentos de identificación",
         "Todos los solicitantes deben aportar un documento de identidad en vigor (DNI, o pasaporte "
         "y documento de residencia en el caso de extranjeros) y su número de identificación fiscal."),
        ("HIP-DOC-02", "Justificación de ingresos",
         "Los trabajadores por cuenta ajena suelen aportar las últimas nóminas y el contrato de "
         "trabajo. Los autónomos suelen aportar las últimas declaraciones de la renta y los "
         f"justificantes de cotización a la Seguridad Social. Número exacto de meses exigido: {TBC}."),
        ("HIP-DOC-03", "Documentos financieros y de la vivienda",
         "Normalmente se piden los extractos bancarios recientes, una relación de los préstamos "
         "existentes y, sobre la vivienda, el contrato de arras o reserva y una nota simple reciente "
         "del Registro de la Propiedad."),
    ]),
    ("EJEMPLO_04_gastos_y_comisiones.pdf", "Comisiones y gastos asociados a la hipoteca", [
        ("HIP-GAS-01", "Comisiones del banco",
         "Entre las comisiones del banco puede figurar la comisión de apertura y cargos por "
         f"productos vinculados. Importes: {TBC}. Solo pueden cobrarse las comisiones que consten en "
         "la ficha de información precontractual."),
        ("HIP-GAS-02", "Gastos de terceros",
         "Otros gastos son la tasación del inmueble, la notaría, el Registro de la Propiedad y la "
         "gestoría. Qué parte asume cada una de las partes la fija la normativa aplicable y el "
         f"contrato: {TBC}."),
        ("HIP-GAS-03", "Impuestos",
         "Según el tipo de vivienda y la comunidad autónoma, pueden aplicarse impuestos de la compra "
         "(como el ITP o el IVA) y el Impuesto de Actos Jurídicos Documentados. No son comisiones que "
         "cobre el banco."),
        ("HIP-GAS-04", "Cuadro de comisiones",
         f"Comisión de apertura: {TBC}. Tasación: {TBC}. Comisión por amortización anticipada "
         f"parcial: {TBC}. Comisión por amortización anticipada total: {TBC}."),
    ]),
    ("EJEMPLO_05_amortizacion.pdf", "Amortización anticipada y condiciones de pago", [
        ("HIP-AMO-01", "Cuadro de amortización",
         "Las hipotecas se pagan normalmente en cuotas mensuales formadas por intereses y capital "
         "(sistema francés: cuota constante, con una parte de intereses que disminuye con el tiempo). "
         f"Plazo máximo ofrecido: {TBC}."),
        ("HIP-AMO-02", "Amortización anticipada parcial",
         "El cliente puede devolver parte del capital antes de tiempo y elegir si reduce la cuota o "
         "el plazo restante. Reducir el plazo suele ahorrar más intereses. "
         f"Importe mínimo y preaviso: {TBC}."),
        ("HIP-AMO-03", "Amortización anticipada total",
         "El cliente puede cancelar la hipoteca por completo devolviendo el capital pendiente más los "
         "intereses devengados. La compensación que corresponda, si la hay, está limitada por la "
         f"normativa y se indica en el contrato: {TBC}."),
        ("HIP-AMO-04", "Impago de cuotas",
         "Si una cuota no se paga pueden aplicarse intereses de demora y el banco puede comunicar el "
         "retraso. El impago persistente puede dar lugar al vencimiento anticipado según el contrato. "
         "Los clientes con dificultades deben contactar con el banco lo antes posible."),
    ]),
    ("EJEMPLO_06_glosario.pdf", "Glosario de terminología hipotecaria", [
        ("HIP-GLO-01", "Capital",
         "Importe de dinero prestado, sin incluir los intereses."),
        ("HIP-GLO-02", "Diferencial",
         "Porcentaje fijo que se suma al índice de referencia en una hipoteca variable o mixta."),
        ("HIP-GLO-03", "Euríbor",
         "Tipo de interés de referencia del mercado interbancario del euro, utilizado como índice "
         "en muchas hipotecas variables."),
        ("HIP-GLO-04", "TAE",
         "Tasa Anual Equivalente. Coste total anual del préstamo expresado en porcentaje, que incluye "
         "los intereses y las comisiones obligatorias, y permite comparar ofertas."),
        ("HIP-GLO-05", "LTV (préstamo sobre valor)",
         "Importe del préstamo dividido entre el valor de tasación o el precio de compra, expresado "
         "en porcentaje."),
        ("HIP-GLO-06", "Amortización",
         "Devolución gradual del préstamo mediante las cuotas programadas."),
    ]),
    ("EJEMPLO_07_producto.pdf", "Condiciones y características de los productos hipotecarios", [
        ("HIP-PRO-01", "Requisitos de acceso",
         f"Edad mínima, residencia e ingresos mínimos exigidos: {TBC}."),
        ("HIP-PRO-02", "Importe, plazo y financiación",
         f"Importe mínimo y máximo del préstamo: {TBC}. Plazo máximo: {TBC}. "
         f"Porcentaje máximo del valor de la vivienda que se financia: {TBC}."),
        ("HIP-PRO-03", "Productos vinculados y bonificaciones",
         "Algunos productos ofrecen un diferencial reducido si el cliente contrata productos "
         "vinculados (domiciliación de nómina, seguros). Condiciones concretas y efecto sobre el "
         f"tipo: {TBC}."),
        ("HIP-PRO-04", "Seguros",
         "Normalmente se exige un seguro de hogar durante toda la vida del préstamo y puede "
         "ofrecerse un seguro de vida. El cliente puede, en general, elegir otra aseguradora que "
         f"ofrezca coberturas equivalentes: {TBC}."),
    ]),
]

# Preguntas de evaluación: (pregunta, id del artículo esperado)
PREGUNTAS = [
    ("¿Qué es una hipoteca a tipo fijo?", "HIP-TIP-01"),
    ("¿Cambia mi cuota si suben los tipos de interés con una hipoteca fija?", "HIP-TIP-01"),
    ("¿Cómo se calcula el interés de una hipoteca variable?", "HIP-TIP-02"),
    ("¿Cada cuánto se revisa el tipo de una hipoteca variable?", "HIP-TIP-02"),
    ("¿Cómo funciona la hipoteca mixta?", "HIP-TIP-03"),
    ("¿Qué tipo de hipoteca me conviene si quiero cuotas estables?", "HIP-TIP-04"),
    ("¿Cuáles son los pasos para pedir una hipoteca?", "HIP-SOL-01"),
    ("¿Qué analiza el banco al estudiar mi solicitud?", "HIP-SOL-02"),
    ("¿Quién hace la tasación de la vivienda?", "HIP-SOL-03"),
    ("¿Qué porcentaje del valor de la casa me financian?", "HIP-SOL-03"),
    ("¿Qué pasa en la notaría al firmar la hipoteca?", "HIP-SOL-04"),
    ("¿Qué es la oferta vinculante?", "HIP-SOL-04"),
    ("¿Qué documento de identidad necesito para pedir una hipoteca?", "HIP-DOC-01"),
    ("¿Qué papeles tengo que presentar si soy autónomo?", "HIP-DOC-02"),
    ("¿Necesito las nóminas para pedir la hipoteca?", "HIP-DOC-02"),
    ("¿Hace falta una nota simple del Registro?", "HIP-DOC-03"),
    ("¿Cobran comisión de apertura?", "HIP-GAS-01"),
    ("¿Quién paga la notaría y la gestoría?", "HIP-GAS-02"),
    ("¿Qué impuestos hay que pagar al comprar con hipoteca?", "HIP-GAS-03"),
    ("¿Cuánto cuesta cancelar la hipoteca antes de tiempo?", "HIP-GAS-04"),
    ("¿Cómo se reparte capital e intereses en cada cuota?", "HIP-AMO-01"),
    ("¿Puedo adelantar parte del capital y reducir la cuota?", "HIP-AMO-02"),
    ("¿Puedo cancelar toda la hipoteca de golpe?", "HIP-AMO-03"),
    ("¿Qué ocurre si dejo de pagar una cuota?", "HIP-AMO-04"),
    ("¿Qué significa TAE?", "HIP-GLO-04"),
    ("¿Qué es el Euríbor?", "HIP-GLO-03"),
    ("¿Qué es el diferencial?", "HIP-GLO-02"),
    ("¿Qué es el LTV?", "HIP-GLO-05"),
    ("¿Qué requisitos hay para acceder a una hipoteca del banco?", "HIP-PRO-01"),
    ("¿Cuál es el plazo máximo de la hipoteca?", "HIP-PRO-02"),
    ("¿Me bajan el diferencial si domicilio la nómina?", "HIP-PRO-03"),
    ("¿Es obligatorio contratar el seguro de hogar con el banco?", "HIP-PRO-04"),
]


def pie(c, numero):
    """Pie de página en tamaño 8 (ruido que limpiar debe quitar)."""
    c.setFont("Helvetica", 8)
    c.drawString(MARGEN, 30, f"Documento de ejemplo - pagina {numero}")


def pagina_nueva(c, numero):
    pie(c, numero)
    c.showPage()
    return numero + 1, ALTO - MARGEN


def crear_pdf(ruta, titulo, articulos):
    c = canvas.Canvas(str(ruta), pagesize=A4)
    numero = 1
    y = ALTO - MARGEN

    # Título (tamaño 20, puede ocupar varios renglones)
    c.setFont("Helvetica-Bold", 20)
    for renglon in simpleSplit(titulo, "Helvetica-Bold", 20, ANCHO_TEXTO):
        c.drawString(MARGEN, y, renglon)
        y -= 26
    y -= 10

    for id_articulo, nombre, texto in articulos:
        cabecera = f"{id_articulo} · {nombre}"
        # La cabecera debe caber en UN renglón; si no, trocear crearía un chunk falso
        assert len(simpleSplit(cabecera, "Helvetica-Bold", 12, ANCHO_TEXTO)) == 1, cabecera

        # No dejar la cabecera sola al final de la página
        if y < MARGEN + 70:
            numero, y = pagina_nueva(c, numero)

        c.setFont("Helvetica-Bold", 12)
        c.drawString(MARGEN, y, cabecera)
        y -= 18

        c.setFont("Helvetica", 10)
        for renglon in simpleSplit(texto, "Helvetica", 10, ANCHO_TEXTO):
            if y < MARGEN:
                numero, y = pagina_nueva(c, numero)
                c.setFont("Helvetica", 10)
            c.drawString(MARGEN, y, renglon)
            y -= 14
        y -= 12

    # Línea de ruido que limpiar descarta por texto exacto
    c.setFont("Helvetica", 10)
    c.drawString(MARGEN, max(y, MARGEN), "Metadatos del documento original")
    pie(c, numero)
    c.save()


def main():
    carpeta_datos = Path("../datos")
    carpeta_eval = Path("../evaluacion")
    carpeta_datos.mkdir(exist_ok=True)
    carpeta_eval.mkdir(exist_ok=True)

    for archivo, titulo, articulos in DOCUMENTOS:
        crear_pdf(carpeta_datos / archivo, titulo, articulos)

    with open(carpeta_eval / "casos_desarrollo.jsonl", "w", encoding="utf-8") as f:
        for pregunta, id_esperado in PREGUNTAS:
            caso = {"question": pregunta, "expected_article_ids": [id_esperado]}
            f.write(json.dumps(caso, ensure_ascii=False) + "\n")

    print(f"{len(DOCUMENTOS)} PDFs y {len(PREGUNTAS)} preguntas generados")


if __name__ == "__main__":
    main()
